// Krzysztof Małysa
#include <iostream>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	cout << "! 1\n" << flush;
	long long x;
	cin >> x; // Solution should be killed by SIGPIPE for reading from closed pipe (checker finished)

	for (;;) {}

	return 0;
}
