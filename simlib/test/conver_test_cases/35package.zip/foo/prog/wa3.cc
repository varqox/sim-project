// Krzysztof Małysa
#include <iostream>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	cout << "! ?\n" << flush;

	for (;;) {} // Solution should be killed after checker verdicts WRONG

	return 0;
}
