#include <bits/stdc++.h>

using namespace std;

#define FOR(x,b,e) for(int x = b; x < (e); ++x)
#define FOR2(x,b,e) for(int x = b; x <= (e); ++x)
#define FORD(x,b,e) for(int x = b; x >= (e); --x)
#define REP(x,n) for(int x = 0; x < (n); ++x)
#define REP2(x,n) for(int x = 0; x <= (n); ++x)
#define VAR(v,n) typeof(n) v = (n)
#define ALL(x) x.begin(), x.end()
#define ALL2(x) x.rbegin(), x.rend()
#define FOREACH(i,c) for(VAR(i, (c).begin()); i != (c).end(); ++i)
#define FOREACH2(i,c) for(VAR(i, (c).rbegin()); i != (c).rend(); ++i)
#define PB push_back
#define ST first
#define ND second
#define PF push_front
#define MP make_pair
#define I(x) static_cast<int>(x)
#define U(x) static_cast<unsigned>(x)
#define SZ(x) I((x).size())
#define eprint(...) fprintf(stderr, __VA_ARGS__)
#define ARR(t,x,n) t *x = new t[n]

typedef unsigned char uchar;
typedef long long LL;
typedef unsigned long long ULL;
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef vector<LL> VLL;
typedef vector<string> VS;
typedef pair<int, int> PII;
typedef pair<LL, LL> PLLLL;
typedef vector<PII> VPII;
typedef vector<PLLLL> VPLLLL;
typedef vector<VPII> VVPII;

template<class T>
inline T abs(T x)
{return x<T() ? -x : x;}

template<class T, class T1>
void mini(T& a, const T1& x)
{if(x < a)a = x;}

template<class T, class T1>
void maxi(T& a, const T1& x)
{if(x > a)a = x;}

#define MOD(x, mod_val) {if(x >= mod_val) x %= mod_val; else if(x < 0){x %= mod_val;if(x < 0) x += mod_val;}}

#ifdef DEBUG

#define D(...) __VA_ARGS__
#define E(...) eprint(__VA_ARGS__)
#define LOG(x) cerr << #x << ": " << (x) << flush
#define LOGN(x) cerr << #x << ": " << (x) << endl

template<class C1, class C2>
ostream& operator<<(ostream& os, const pair<C1, C2>& _)
{return os << "(" << _.ST << "," << _.ND << ")";}

template<class T>
ostream& operator<<(ostream& os, const vector<T>& _)
{
	os << "{";
	if(_.size())
	{
		os << *_.begin();
		for(typename vector<T>::const_iterator i=++_.begin(); i!=_.end(); ++i)
			os << ", " << *i;
	}
	return os << "}";
}

template<class T>
ostream& operator<<(ostream& os, const deque<T>& _)
{
	os << "{";
	if(_.size())
	{
		os << *_.begin();
		for(typename deque<T>::const_iterator i=++_.begin(); i!=_.end(); ++i)
			os << ", " << *i;
	}
	return os << "}";
}

template<class T, class K>
ostream& operator<<(ostream& os, const set<T, K>& _)
{
	os << "{";
	if(_.size())
	{
		os << *_.begin();
		for(typename set<T>::const_iterator i=++_.begin(); i!=_.end(); ++i)
			os << ", " << *i;
	}
	return os << "}";
}

template<class T, class K>
ostream& operator<<(ostream& os, const map<T, K>& _)
{
	os << "{";
	if(_.size())
	{
		os << _.begin()->ST << " => " << _.begin()->ND;
		for(typename map<T, K>::const_iterator i=++_.begin(); i!=_.end(); ++i)
			os << ", " << i->ST << " => " << i->ND;
	}
	return os << "}";
}

template<class Iter>
void out(ostream& os, Iter begin, Iter end)
{
	os << "{";
	if(begin != end)
	{
		os << *begin;
		for(Iter i = ++begin; i != end; ++i)
			os << ", " << *i;
	}
	os << "}";
}

#define OUT(a, b) cerr << #a << ": ", out(cerr, a, b), eprint("\n")

#else
#define D(...)
#define E(...)
#define LOG(x)
#define LOGN(x)
#define OUT(...)
#endif

inline bool good(int n, int m, int a, int b) { return (a >= 0 && a < n && b >= 0 && b < m); }

int main() {
	int _;
	scanf("%i", &_);
	REP (__, _) {
		int n, m, a, b, x, y;
		scanf("%i%i%i%i", &n, &m, &a, &b);
		char t[n+1][m+1], s[a+1][b+1];
		vector<pair<short, short> > pp;
		pp.reserve(a*b);
		REP (i, n)
			scanf("%s", t[i]);
		REP (i, a)
			scanf("%s", s[i]);
		REP (i, a)
			REP (j, b) {
				if (s[i][j] == 'x')
					pp.PB(MP(i, j));
			}
		REP (i, n)
			REP (j, m) {
				if (t[i][j] == 'x') {
					FOREACH(k, pp) {
						x = i + k->ST - pp[0].ST;
						y = j + k->ND - pp[0].ND;
						if (!good(n, m, x, y) || t[x][y] == '.')
							goto no;
						else
							t[x][y] = '.';
					}
				}
			}
		printf("TAK\n");
		continue;
	no:
		printf("NIE\n");
	}
	return 0;
}
